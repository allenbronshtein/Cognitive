# Allen Bronshtein 206228751
""" This part of our executive handles all kinds of errors
that may happen"""
import Data
import Vocabulary
from Utilities import Actions


def BadArgumentsHandler():
    errors = ""
    if Data.TOO_LITTLE_ARGUMENTS:
        errors = errors + Vocabulary.TOO_LITTLE_ARGUMENTS_ERR + "," + " Required " + str(
            Data.NUMBER_OF_ARGUMENTS_REQUIRED - Data.NUMBER_OF_ARGUMENTS_GIVEN) + " more.\n"
    if Data.TOO_MUCH_ARGUMENTS:
        errors += Vocabulary.TOO_MUCH_ARGUMENTS_ERR
    if not Data.FIRST_ARGUMENT_OK and Data.NUMBER_OF_ARGUMENTS_GIVEN >= 1:
        errors += Vocabulary.BAD_FIRST_ARGUMENT_ERR
    if not Data.SECOND_ARGUMENT_OK and Data.NUMBER_OF_ARGUMENTS_GIVEN >= 2:
        errors += Vocabulary.BAD_SECOND_ARGUMENT_ERR
    if not Data.THIRD_ARGUMENT_OK and Data.NUMBER_OF_ARGUMENTS_GIVEN >= 3:
        errors += Vocabulary.BAD_THIRD_ARGUMENT_ERR
    if not Data.FOURTH_ARGUMENT_OK and Data.NUMBER_OF_ARGUMENTS_GIVEN >= 4:
        errors += Vocabulary.BAD_FOURTH_ARGUMENT_ERR
    Actions.TalkAndTerminate(errors)


def MissingFilesHandler():
    errors = ""
    if not Data.POLICY_FILE_EXISTS:
        errors += Vocabulary.POLICY_FILE_MISSING_ERR
    if not Data.QTABLE_FILE_EXISTS:
        errors += Vocabulary.QTABLE_FILE_MISSING_ERR
    if not Data.PLANS_FILE_EXISTS:
        errors += Vocabulary.PLANS_FILE_MISSING_ERR
    if not Data.EXPLORECONST_FILE_EXISTS:
        errors += Vocabulary.EXPLORECONST_FILE_MISSING_ERR
    Actions.TalkAndTerminate(errors)
