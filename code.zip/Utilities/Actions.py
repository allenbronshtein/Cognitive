# Allen Bronshtein 206228751
import os
import sys
from sys import argv
import Data
from os import path

from Executers.RandomExe import RandomExecutorBasic
from Executers.RandomExeExtended import RandomExecutor
from Executers.BestPlanExe import PlanDispatcher
from Executers.DummyExe import Dummy
from pddlsim.local_simulator import LocalSimulator

""" This part of our executive takes actions"""


def CheckArguments():
    num_args = len(argv)
    Data.NUMBER_OF_ARGUMENTS_GIVEN = num_args
    if num_args == Data.NUMBER_OF_ARGUMENTS_REQUIRED:
        Data.ARGUMENTS_OK = True
    if num_args >= 1 and argv[0] == Data.NAME_OF_FIRST_ARGUMENT:
        Data.FIRST_ARGUMENT_OK = True
    if num_args >= 2 and (argv[1] == Data.NAME_OF_SECOND_ARGUMENT1 or
                          argv[1] == Data.NAME_OF_SECOND_ARGUMENT2):
        Data.SECOND_ARGUMENT_OK = True
        if argv[1] == "-L":
            Data.REQUESTED_TO_LEARN = True
        else:
            Data.REQUESTED_TO_EXECUTE = True
    if num_args >= 3:
        if path.exists(argv[2]) and argv[2].endswith(".pddl"):
            Data.THIRD_ARGUMENT_OK = True
            Data.DOMAIN_NAME = argv[2]
    if num_args >= 4:
        if path.exists(argv[3]) and argv[3].endswith(".pddl"):
            Data.FOURTH_ARGUMENT_OK = True
            Data.PROBLEM_NAME = argv[3]
        Data.TOO_LITTLE_ARGUMENTS = False
    if num_args >= 5:
        Data.TOO_MUCH_ARGUMENTS = True


def TalkOnly(error):
    sys.stderr.write('\x1b[1;31m' + error + "\n" + '\x1b[0m')


def TalkAndTerminate(error):
    sys.stderr.write('\x1b[1;31m' + error + "\n" + '\x1b[0m')
    exit(0)


def RemoveGarbageFiles():
    if path.exists("tmp_problem_generation"):
        os.remove("tmp_problem_generation")
    if path.exists("execution.details"):
        os.remove("execution.details")
    if path.exists("tmp.ipc"):
        os.remove("tmp.ipc")


def PrepareExe():
    Data.RANDOM_EXE = RandomExecutor()
    Data.PLAN_EXE = PlanDispatcher()
    Data.DUMMY_EXE = Dummy()
    LocalSimulator().run(Data.DOMAIN_NAME, Data.PROBLEM_NAME, Data.DUMMY_EXE)


def ChooseGoalsByLessSteps():
    Data.SHOULD_REMEMBER_GOALS = True
    Data.DISCOVERED_SOMETHING_NEW = True
    while True:
        Data.NUMBER_OF_DISCOVERIES = 0
        LocalSimulator().run(Data.DOMAIN_NAME, Data.PROBLEM_NAME, Data.RANDOM_EXE)
        if Data.NUMBER_OF_DISCOVERIES == 0:
            break
        if Data.STOP:
            Data.STOP = False
            break
    min_steps = float('inf')
    if len(Data.BEST_REMEMBERED_GOALS) != 0:
        _input = raw_input("Found goal! Press any key to continue")
        for entry in Data.BEST_REMEMBERED_GOALS:
            if entry[1] < min_steps:
                min_steps = entry[1]
                Data.GOAL = entry[0]

    # Try find goal again
    else:
        LocalSimulator().run(Data.DOMAIN_NAME, Data.PROBLEM_NAME, RandomExecutorBasic())
        if len(Data.BEST_REMEMBERED_GOALS) == 0:
            print "Cannot find goal, terminating"
            exit(0)
        print Data.GOAL
        _input = raw_input("Found goal! Press any key to continue")
    Data.ClearMemoryOfStatesAndActions()
