# Allen Bronshtein 206228751

""" This part of our executive hold his vocabulary,
and hold sentences to interact with us"""
import Data

TOO_LITTLE_ARGUMENTS_ERR = "Bad number of arguments: not enough given"
TOO_MUCH_ARGUMENTS_ERR = "Bad number of arguments: too much given\n"
BAD_FIRST_ARGUMENT_ERR = "Bad first argument given\n"
BAD_SECOND_ARGUMENT_ERR = "Bad second argument given\n"
BAD_THIRD_ARGUMENT_ERR = "Bad third argument given\n"
BAD_FOURTH_ARGUMENT_ERR = "Bad fourth argument given\n"
UNKNOWN_EXECEPTION_ERR = "Something unknown happened ...\n"
POLICY_FILE_MISSING_ERR = "Cannot find " + Data.POLICY_FILE_NAME + "\n"
QTABLE_FILE_MISSING_ERR = "Cannot find " + Data.QTABLE_FILE_NAME + "\n"
PLANS_FILE_MISSING_ERR = "Cannot find " + Data.PLANS_FILE_NAME + "\n"
EXPLORECONST_FILE_MISSING_ERR = "Cannot find " + Data.EXPLORECONST_FILE_NAME + "\n"
