import os

os.system("rm Files/ExploreConst")
os.system("touch Files/ExploreConst")
os.system("rm Files/PLANS")
os.system("touch Files/PLANS")
os.system("rm Qtables/*.pickle")